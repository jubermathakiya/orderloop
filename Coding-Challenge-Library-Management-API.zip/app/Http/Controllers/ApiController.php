<?php 

namespace App\Http\Controllers;

/**
 * @OA\Info(
 *     title="Library Management API",
 *     version="1.0.0",
 *     description="This is the API documentation for Library Management.",
 *     @OA\Contact(
 *         email="support@example.com"
 *     )
 * )
 */
class ApiController extends Controller
{
    //
}
